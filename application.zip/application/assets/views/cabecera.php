<header id="cabecera">
        <div class="cabecera">
            <li id="li-izquierda">
                <ul><div id="cabecera-img"></div></ul>
                <ul><a href='<?=base_url?>/index.php'>Inicio</a></ul>
                <ul><a href='<?=base_url?>/assets/views/buscar-evento.php'>Buscar</a></ul>
                <ul><a href='<?=base_url?>/assets/views/crear-evento.php'>Crear evento</a></ul>
                <ul><a href='<?=base_url?>/assets/views/chat.php'>Chat</a></ul>
            </li>
            <li>
                <ul><a href='<?=base_url?>/assets/views/perfil.php'>Perfil</a></ul>
            </li>
        </div>
</header>
