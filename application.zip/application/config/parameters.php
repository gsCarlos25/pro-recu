<?php

define("base_url", "http://localhost/application");

?>

