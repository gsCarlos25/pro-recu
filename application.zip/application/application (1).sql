-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 04-03-2023 a las 12:50:57
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `application`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deporte`
--

CREATE TABLE `deporte` (
  `id` int(3) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `imagen` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `deporte`
--

INSERT INTO `deporte` (`id`, `nombre`, `imagen`) VALUES
(1, 'Fútbol', 'futbol.jpg'),
(2, 'Baloncesto', 'baloncesto.png'),
(3, 'Ciclismo', 'ciclismo.jpg'),
(4, 'Hockey', 'hockey.jpg'),
(5, 'Padel', 'padel.jpg'),
(6, 'Senderismo', 'senderismo.jpg'),
(7, 'Tenis', 'tenis.jpg'),
(8, 'Voley', 'voley.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evento`
--

CREATE TABLE `evento` (
  `id` int(5) NOT NULL,
  `deporte` int(3) NOT NULL,
  `n_personas` int(2) NOT NULL,
  `fecha` varchar(30) NOT NULL,
  `titulo` varchar(40) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `descripcion` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `evento`
--

INSERT INTO `evento` (`id`, `deporte`, `n_personas`, `fecha`, `titulo`, `id_usuario`, `direccion`, `descripcion`) VALUES
(1, 1, 3, '2022-12-14', 'Pachanga futbol', 1, 'Granada', 'Necesitamos gente para un partido en granada'),
(2, 2, 3, '2022-12-16', 'Partido de basket', 2, 'Granada', 'Vente y juega con nosotros somos una peña');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `id` int(11) NOT NULL,
  `id_evento` int(5) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `mensaje` varchar(255) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id`, `id_evento`, `nombre`, `mensaje`, `fecha`) VALUES
(2, 1, 'prueba', 'hola', '2022-12-15 03:16:19'),
(3, 1, 'prueba', 'que tal', '2022-12-15 03:16:23'),
(4, 1, 'prueba', 'yo bien', '2022-12-15 03:16:27'),
(5, 1, 'prueba', 'y tu', '2022-12-15 03:16:29'),
(6, 1, 'prueba', '<zx', '2022-12-15 03:26:03'),
(7, 1, 'prueba', 'asdw', '2022-12-15 03:26:06'),
(8, 1, 'prueba', '<asd', '2022-12-15 03:26:09'),
(9, 1, 'prueba', 'asd213', '2022-12-15 03:26:28'),
(10, 1, 'prueba', '<>', '2022-12-15 03:26:33'),
(11, 1, 'prueba', '<', '2022-12-15 03:26:34'),
(12, 1, 'prueba', '<a', '2022-12-15 03:26:35'),
(13, 1, 'prueba', '<s', '2022-12-15 03:26:37'),
(14, 1, 'prueba', '<df', '2022-12-15 03:26:39'),
(15, 1, 'prueba', '<', '2022-12-15 03:26:41'),
(16, 1, 'prueba', 'asd', '2022-12-15 03:26:51'),
(17, 1, 'prueba', 'asd', '2022-12-15 03:26:51'),
(18, 1, 'prueba', 'asd', '2022-12-15 03:26:52'),
(19, 1, 'prueba', 'asd', '2022-12-15 03:26:52'),
(20, 1, 'prueba', 'sad', '2022-12-15 03:26:53'),
(21, 1, 'prueba', 'asd', '2022-12-15 03:29:36'),
(22, 1, 'prueba', 'asd', '2022-12-15 03:29:36'),
(23, 1, 'prueba', 'w', '2022-12-15 03:29:37'),
(24, 1, 'prueba', 'eqwe', '2022-12-15 03:29:38'),
(25, 1, 'prueba', 'asd', '2022-12-15 03:29:38'),
(26, 1, 'asd', 'hola', '2023-03-04 11:26:03'),
(27, 1, 'asd', 'que tall', '2023-03-04 11:26:08'),
(28, 1, 'asd', 'Hola +', '2023-03-04 11:42:33'),
(29, 2, 'asd', 'hola', '2023-03-04 11:42:43');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `nom_us` varchar(25) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `apellidos` varchar(25) NOT NULL,
  `descripcion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `correo`, `pass`, `nom_us`, `nombre`, `apellidos`, `descripcion`) VALUES
(1, 'asd@gmail.com', 'asdfghjK1', 'asd', 'asd', 'asd', ''),
(2, 'prueba@gmail.com', 'asdfghjK1', 'prueba', 'Jose Antonio', 'Torres', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_apuntado`
--

CREATE TABLE `usuario_apuntado` (
  `id` int(5) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_evento` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `deporte`
--
ALTER TABLE `deporte`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `evento`
--
ALTER TABLE `evento`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `titulo` (`titulo`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `evento_ibfk_2` (`deporte`);

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mens_ev_fk` (`id_evento`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD UNIQUE KEY `nom_us` (`nom_us`);

--
-- Indices de la tabla `usuario_apuntado`
--
ALTER TABLE `usuario_apuntado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_evap` (`id_evento`),
  ADD KEY `fk_usap` (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `deporte`
--
ALTER TABLE `deporte`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `evento`
--
ALTER TABLE `evento`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuario_apuntado`
--
ALTER TABLE `usuario_apuntado`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `evento`
--
ALTER TABLE `evento`
  ADD CONSTRAINT `evento_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `evento_ibfk_2` FOREIGN KEY (`deporte`) REFERENCES `deporte` (`id`);

--
-- Filtros para la tabla `usuario_apuntado`
--
ALTER TABLE `usuario_apuntado`
  ADD CONSTRAINT `fk_evap` FOREIGN KEY (`id_evento`) REFERENCES `evento` (`id`),
  ADD CONSTRAINT `fk_usap` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
